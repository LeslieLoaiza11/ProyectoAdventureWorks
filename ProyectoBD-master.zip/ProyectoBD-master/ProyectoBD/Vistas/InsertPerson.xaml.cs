﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace ProyectoBD.Vistas
{
    /// <summary>
    /// Lógica de interacción para InsertPerson.xaml
    /// </summary>
    public partial class InsertPerson : Window
    {
        public InsertPerson()
        {
            InitializeComponent();
        }
        private void btn_return_Click(object sender, RoutedEventArgs e)
        {
            Owner.Show();
            this.Close();
        }

        private void btn_save_Click(object sender, RoutedEventArgs e)
        {
            if(txt_title.Text == "Title" || txt_name.Text == "Name" || txt_middleName.Text == "Middle name" || 
                txt_lastName.Text == "Last name" || txt_suffix.Text == "Suffix" || txt_type.Text == "Type" || 
                txt_phoneNumer.Text == "Phone number" || txt_email.Text == "Email Adress" || txt_cardNumer.Text == "Card number" ||
                txt_cardType.Text == "Card type" )
            {
                MessageBox.Show("LLenar todos los campos correctamente.");
            }
            else
            {
                string idPersona = registrarPersona();
                registrarTelefono(idPersona);
                registrarEmail(idPersona);
                registrarTarjeta(idPersona);
            }


        }

        private String registrarPersona()
        {
            string respuesta = "";
            try
            {
                SqlConnection conn = new SqlConnection("Data Source=MALBEC\\SQLEXPRESS;Initial Catalog=AdventureWorks2016;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
                SqlDataAdapter adapter = new SqlDataAdapter("SPI_Person_Person", conn);
                conn.Open();
                adapter.SelectCommand.CommandType = CommandType.StoredProcedure;
                adapter.SelectCommand.Parameters.Add("@personType", SqlDbType.NChar).Value = txt_type.Text;
                adapter.SelectCommand.Parameters.Add("@title", SqlDbType.NVarChar).Value = txt_title.Text;
                adapter.SelectCommand.Parameters.Add("@firstName", SqlDbType.NVarChar).Value = txt_name.Text;
                adapter.SelectCommand.Parameters.Add("@middleName", SqlDbType.NVarChar).Value = txt_middleName.Text;
                adapter.SelectCommand.Parameters.Add("@lastName", SqlDbType.NVarChar).Value = txt_lastName.Text;
                adapter.SelectCommand.Parameters.Add("@suffix", SqlDbType.NVarChar).Value = txt_suffix.Text;
                adapter.SelectCommand.Parameters.Add("@emailPromotion", SqlDbType.Int).Value = 0;
                adapter.SelectCommand.Parameters.Add("@estado", SqlDbType.Int, 5).Direction = ParameterDirection.Output;
                adapter.SelectCommand.Parameters.Add("@salida", SqlDbType.NVarChar, 1000).Direction = ParameterDirection.Output;
                adapter.SelectCommand.ExecuteNonQuery();
                respuesta = adapter.SelectCommand.Parameters["@estado"].Value.ToString();
                MessageBox.Show("Persona Registrada Correctamente.");
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            return respuesta;
        }

        private void registrarTelefono(string idPersona)
        {
            string respuesta = "";
            try
            {
                SqlConnection conn = new SqlConnection("Data Source=MALBEC\\SQLEXPRESS;Initial Catalog=AdventureWorks2016;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
                SqlDataAdapter adapter = new SqlDataAdapter("SPI_Person_PersonPhone", conn);
                conn.Open();
                adapter.SelectCommand.CommandType = CommandType.StoredProcedure;
                adapter.SelectCommand.Parameters.Add("@idPersona", SqlDbType.Int).Value = Convert.ToInt32(idPersona);
                adapter.SelectCommand.Parameters.Add("@phoneNumber", SqlDbType.NVarChar).Value = txt_phoneNumer.Text;
                adapter.SelectCommand.Parameters.Add("@phoneNumberType", SqlDbType.Int).Value = 1;

                adapter.SelectCommand.Parameters.Add("@estado", SqlDbType.Int, 20).Direction = ParameterDirection.Output;
                adapter.SelectCommand.Parameters.Add("@salida", SqlDbType.NVarChar, 1000).Direction = ParameterDirection.Output;
                adapter.SelectCommand.ExecuteNonQuery();
                respuesta = adapter.SelectCommand.Parameters["@estado"].Value.ToString();
                conn.Close();
                
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }

        private void registrarEmail(string idPersona)
        {
            string respuesta = "";
            try
            {
                SqlConnection conn = new SqlConnection("Data Source=MALBEC\\SQLEXPRESS;Initial Catalog=AdventureWorks2016;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
                SqlDataAdapter adapter = new SqlDataAdapter("SPI_Person_Email", conn);
                conn.Open();
                adapter.SelectCommand.CommandType = CommandType.StoredProcedure;
                adapter.SelectCommand.Parameters.Add("@idPersona", SqlDbType.Int).Value = Convert.ToInt32(idPersona);
                adapter.SelectCommand.Parameters.Add("@email", SqlDbType.NVarChar).Value = txt_email.Text;

                adapter.SelectCommand.Parameters.Add("@estado", SqlDbType.Int, 20).Direction = ParameterDirection.Output;
                adapter.SelectCommand.Parameters.Add("@salida", SqlDbType.NVarChar, 1000).Direction = ParameterDirection.Output;
                adapter.SelectCommand.ExecuteNonQuery();
                respuesta = adapter.SelectCommand.Parameters["@estado"].Value.ToString();
                conn.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }

        private void registrarTarjeta(string idPersona)
        {
            string respuesta = "";
            try
            {
                SqlConnection conn = new SqlConnection("Data Source=MALBEC\\SQLEXPRESS;Initial Catalog=AdventureWorks2016;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
                SqlDataAdapter adapter = new SqlDataAdapter("SPI_Sales_CreditCard", conn);
                conn.Open();
                adapter.SelectCommand.CommandType = CommandType.StoredProcedure;
                adapter.SelectCommand.Parameters.Add("@idPersona", SqlDbType.Int).Value = Convert.ToInt32(idPersona);
                adapter.SelectCommand.Parameters.Add("@cardType", SqlDbType.NVarChar).Value = txt_cardType.Text;
                adapter.SelectCommand.Parameters.Add("@cardNumber", SqlDbType.NVarChar).Value = txt_cardNumer.Text;
                adapter.SelectCommand.Parameters.Add("@expMonth", SqlDbType.TinyInt).Value = txt_expMonth.Text;
                adapter.SelectCommand.Parameters.Add("@expYear", SqlDbType.SmallInt).Value = txt_expYear.Text;

                adapter.SelectCommand.Parameters.Add("@estado", SqlDbType.Int, 20).Direction = ParameterDirection.Output;
                adapter.SelectCommand.Parameters.Add("@salida", SqlDbType.NVarChar, 1000).Direction = ParameterDirection.Output;
                adapter.SelectCommand.ExecuteNonQuery();
                respuesta = adapter.SelectCommand.Parameters["@estado"].Value.ToString();
                conn.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }


        private void txt_title_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            txt_title.Text = "";
        }

        private void txt_name_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            txt_name.Text = "";
        }

        private void txt_middleName_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            txt_middleName.Text = "";
        }

        private void txt_lastName_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            txt_lastName.Text = "";
        }

        private void txt_suffix_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            txt_suffix.Text = "";
        }

        private void txt_type_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            txt_type.Text = "";
        }

        private void txt_phoneNumer_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            txt_phoneNumer.Text = "";
        }

        private void txt_email_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            txt_email.Text = "";
        }

        private void txt_cardNumer_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            txt_cardNumer.Text = "";
        }

        private void txt_cardType_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            txt_cardType.Text = "";
        }

        private void txt_expMonth_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            txt_expMonth.Text = "";
        }

        private void txt_expYear_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            txt_expYear.Text = "";
        }
    }
}
